<?php
session_start();
if (!isset($_SESSION['username'])) { //not logged in
    //redirect to homepage
    header("Location: SIGNIN.html.php");
}
?>
<!doctype html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MasterMinds</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

       
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style4.css" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>

</head>
<body>
<?php
include("database.php");
?>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">HOME</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                                        <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">APTITUDE <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="quantitative.php">QUANTITATIVE</a>
                            </li>
                            <li>
                                <a href="verbal.php">VERBAL</a>
                            </li>
                            <li>
                                <a href="logical.php">LOGICAL</a>
                            </li>
							<li>
                                <a href="analysis.php">DATA ANALYSIS</a>
                            </li>
</ul>
					<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">INTERVIEW <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="technical.php">TECHNICAL</a>
                            </li>
                            <li>
                                <a href="hr.php">HR</a>
                            </li>
<li>
                                <a href="gd.php">GROUP DISCUSSION</a>
                            </li>

</ul>
 <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">STUDY SOURCES <b class="caret"></b></a>
<ul class="dropdown-menu">
 <li class="dropdown"><a href="#" class="dropdown-toggle" data toggle="dropdown">IT/COMPUTERS <b class=""></b></a>
<ul class="dropdown dropdown-submenu">

									<li><a href="java.php">JAVA</a></li>
									<li><a href="dbms.php">DBMS</a></li>
									<li><a href="dsa.php">DSA</a></li>
									<li><a href="cn.php">CN</a></li>
<li><a href="os.php">OS</a></li>

</ul>
							</li>
<li class="dropdown dropdown-submenu"><a href="#" class="dropdown-toggle" data toggle="dropdown dropdown-submenu">ELECTRONICS <b class=""></b></a>
								<ul class="dropdown dropdown-submenu">
									<li><a href="vlsi.php">VLSI DESIGN</a></li>
									<li><a href="dsp.php">DSP</a></li>
									<li><a href="power.php">POWER ELECTRONICS</a></li>
									<li><a href="ss.php">SIGNALS & SYSTEMS</a></li>
								</ul>
							</li>                              
                            <li class="dropdown dropdown-submenu"><a href="#" class="dropdown-toggle" data toggle="dropdown dropdown-submenu">PRODUCTION <b class=""></b></a>
								<ul class="dropdown dropdown-submenu">
									<li><a href="som.php">SOM</a></li>
									<li><a href="tom.php">TOM</a></li>
									<li><a href="thermo.php">THERMODYNAMICS</a></li>
									<li><a href="fm.php">FLUID MECHANICS</a></li>
								</ul>
							</li> 
</ul>  
</li>                
 <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">TEST YOURSELF <b class="caret"></b></a>
                        <ul class="dropdown-menu">


                            <li>
                                <a href="qtest.php">APTITUDE</a>
                            </li>
                            <li>
                                <a href="ftest.php">FUNCTIONAL EXPERTISE</a>
                            </li>
                            
                        </ul>
                    </li>
<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">MISCELLANEOUS <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="rounds.php">COMPANY ROUNDS</a>
                            </li>
                            <li>
                                <a href="papers.php">COMPANY PAPERS</a>
                            </li>
</ul>
</li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">PROFILE<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            
                            <li>
                                <a href="register.html">Change Password</a>
                            </li>  
							
                            <li>
                                <a href="logout.php">LOG OUT</a>
                            </li>  
							</ul>
							
                    </li>
                </ul>
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	 <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        
        <!-- /.row -->
</div><br><br>
    <!-- /.container -->

    <!-- jQuery -->
	<div class="container">
			<!-- Codrops top bar -->
            <!--/ Codrops top bar -->
			
			<section>
                <div id="container_buttons">
                    <p>
                        <a class="a_demo_four" href="Ranklist.php">
                            Rank List
                        </a>
                    </p>
                    <p>
                        <a href="Studentdetails.php" class="a_demo_four">
                          Student Details
                        </a>
                    </p>
                    <p>
                        <a href="uploaddata1.php" class="a_demo_four">
                          Add Data
                        </a>
                    </p>
					<p>
                        <a href="addstudents1.php" class="a_demo_four">
                          Add Students
                        </a>
                    </p>
					<p>
                        <a href="#" class="a_demo_four">
                          Delete Students
                        </a>
                    </p>
                </div>
			</section>
        </div>
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
<!--<?php
echo"<br><br><br>";
echo "<a href='Ranklist.php'> Rank List </a><br>";
echo "<a href='Studentdetails.php'> Student Details </a><br>";
echo"<a href='uploaddata1.php'>Add Data</a><br>";
echo"<a href= 'addstudents1.php'> Add students </a>";
?>-->
</body>
</html> 	